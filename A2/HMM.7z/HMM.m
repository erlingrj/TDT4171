clc
clear all
% Transistion matrix
T = [0.7 0.3;
     0.3 0.7];
% Sensor matrices 
% Sensor matrix for E = True
Ot = [0.9 0.0;
      0.0 0.2];
%Sensor matrix for E = False
Of = [0.1 0.0;
      0.0 0.8];

%Initial value: chance of rain with no prior knowledge
x0 =[0.5 0.5]';

%Normalizing function
normalize = @(matrix)(matrix./sum(sum(matrix)));

%Forward filter function
forwardf = @(T,O,f_prev) (normalize(O*T'*f_prev));

%Backward smoothing function
backwards = @(T,O,b_next)(T*O*b_next);

%Evidence vecotor
e = input('Input boolean Evidence vector in following format: "[1 1 0 1]"');
fprintf('Evidence vector: \n')
disp(e)

n = length(e);

%Probability distribution. X(1) = day0, X(2) = day1 and etc.
X = zeros(2,n+1);
X(:,1) = x0; %Initial probability

% Forward filtering
for i = 1:n
    if e(i) == 1        
        X(:,i+1) = forwardf(T,Ot,X(:,i));
    else
        X(:,i+1) = forwardf(T,Of,X(:,i));
    end
end

fprintf('Probability distribution after filtering X = \n')
disp(X)


%Backward smoothing
b = [1;1]; %Initial backward message

for i = n:-1:1
    % Smooth probability distribution with backwards message   
    fprintf('Backward message %i: <%.4f, %.4f>\n', i+1,b)
    X(:,i+1) = normalize(X(:,i+1).*b);
    if e(i) == 1
         b = backwards(T,Ot,b);
    else
        b = backwards(T,Of,b);
    end
    
end

fprintf('Probability distribution after filtering and smoothing X = \n')
disp(X)
        
        
        
    
